# Flutter Login Fashion UI

Layouting the UI for Login Fashion

## Video Youtube

[![Watch the video](https://img.youtube.com/vi/iL6qPggKKJ8/sddefault.jpg)](https://youtu.be/iL6qPggKKJ8)

https://youtu.be/iL6qPggKKJ8




## ScreenShot

| Login        |
|--------------|
| <img src="img1.png" width="500"/>



