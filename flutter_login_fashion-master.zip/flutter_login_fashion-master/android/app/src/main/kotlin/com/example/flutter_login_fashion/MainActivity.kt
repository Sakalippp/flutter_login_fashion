package com.example.flutter_login_fashion

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
